//1. feladat
var tomb = ["Első elem", "Második elem", "Harmadik elem"];

document.getElementById("gomb1").addEventListener("click", function() {
    document.getElementById("megjelenito").textContent = tomb[0];
});

document.getElementById("gomb2").addEventListener("click", function() {
    document.getElementById("megjelenito").textContent = tomb[1];
});

document.getElementById("gomb3").addEventListener("click", function() {
    document.getElementById("megjelenito").textContent = tomb[2];
});

//2. feladat
document.getElementById("osszegGomb").addEventListener("click", function() {
    document.getElementById("megjelenito").textContent = tomb.join(' ');
});

//3. feladat
document.getElementById("hozzaadGomb").addEventListener("click", function() {
    var ujElem = document.getElementById("szovegInput").value;
    tomb.push(ujElem);
});

//4. feladat
document.getElementById("tombHosszaGomb").addEventListener("click", function() {
    var hossz = tomb.length;
    document.getElementById("megjelenito").textContent = "A tömb " + hossz + " elemet tartalmaz.";
});

//5. feladat
document.getElementById("torlesGomb").addEventListener("click", function() {
    var torlendoIndex = parseInt(document.getElementById("torlesIndexInput").value);
    if (!isNaN(torlendoIndex) && torlendoIndex >= 0 && torlendoIndex < tomb.length) {
        tomb.splice(torlendoIndex, 1);
    }
});